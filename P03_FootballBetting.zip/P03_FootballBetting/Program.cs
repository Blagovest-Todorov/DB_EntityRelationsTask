﻿using System;

namespace P03_FootballBetting
{
    class Program
    {
        static void Main(string[] args)
        {
           var context = new D
        }
    }
}
